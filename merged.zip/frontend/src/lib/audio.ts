class AudioService {
  private popSound: HTMLAudioElement | null = null
  private dingSound: HTMLAudioElement | null = null
  private successSound: HTMLAudioElement | null = null
  private errorSound: HTMLAudioElement | null = null
  private initialized = false

  constructor() {
    this.init()
  }

  private init() {
    if (this.initialized || typeof window === 'undefined') return
    
    try {
      this.popSound = new Audio('/sounds/pop.wav')
      this.dingSound = new Audio('/sounds/ding.wav')
      this.successSound = new Audio('/sounds/success.wav')
      this.errorSound = new Audio('/sounds/error.wav')

      // Preload the metadata so playback is instant
      this.popSound.preload = 'auto'
      this.dingSound.preload = 'auto'
      this.successSound.preload = 'auto'
      this.errorSound.preload = 'auto'

      this.initialized = true
    } catch (e) {
      console.warn('Audio initialization failed', e)
    }
  }

  private playSound(audioEl: HTMLAudioElement | null) {
    if (!audioEl) return
    try {
      // Allows overlapping sounds
      const clone = audioEl.cloneNode() as HTMLAudioElement
      // Set volume slightly lower for standard UI feel
      clone.volume = 0.5
      const playPromise = clone.play()
      
      // Handle browser auto-play policies silently
      if (playPromise !== undefined) {
        playPromise.catch(_error => {
          // Playback blocked by browser policy, perfectly normal on fresh load
        });
      }
    } catch (e) {
      // Ignore
    }
  }

  playPop() {
    this.playSound(this.popSound)
  }

  playDing() {
    this.playSound(this.dingSound)
  }

  playAnnouncement() {
    // Falls back to success for generic announcements
    this.playSound(this.successSound)
  }

  playSuccess() {
    this.playSound(this.successSound)
  }

  playError() {
    this.playSound(this.errorSound)
  }
}

export const audio = new AudioService()
